#!/bin/bash
# Program:
#	This is my first shell script,shows "Hello World!" in your screen.
# History:
# 2018/11/09 Jianghairui First release
PATH=$PATH
export PATH
echo -e "I will use 'test' command to do a lots of judgements."
read -p "Please input one filename: " filename
test -e $filename && echo 'file exist' || echo 'file not exist: ' $filename
test -f $filename && echo $filename 'is a file'
test -d $filename && echo $filename 'is a directory'
test -r $filename && fr='r' || fr='-'
test -w $filename && fw='w' || fw='-'
test -x $filename && fx='x' || fx='-'
echo 'the auth data: ' $fr $rw $fx
