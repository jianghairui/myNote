#!/bin/bash
PATH=$PATH
export PATH

read -p "Please input a number to addTo: " num
i=1
s=0
while [ $i -le $num ]
do
	s=$(($s+$i))
	i=$(($i+1))
done
echo "the result is $s"

