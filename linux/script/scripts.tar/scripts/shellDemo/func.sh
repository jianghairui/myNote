#!/bin/sh
printit() {
	echo -n "the functionname is $0  $1 $2 \n"
}
printit -version -list
