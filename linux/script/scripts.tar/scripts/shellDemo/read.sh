#!/bin/bash
# Program:
#	User inputs his first name and last name.  Program show his full name.
# History:
# 2018/11/09 Jianghairui First release
PATH=$PATH
export PATH
read -p "Please input your first name: " firstname
read -p "Please input your last name: " lastname
echo -e "\nYour full name is: " $firstname $lastname
