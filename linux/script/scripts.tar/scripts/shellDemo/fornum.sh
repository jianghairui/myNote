#!/bin/bash
PATH=$PATH
export PATH

read -p "Please input a number to addTo: " num
s=0
for((i=1;i<=$num;i++))
do
	s=$(($s+$i))
done
echo "the result is $s"

