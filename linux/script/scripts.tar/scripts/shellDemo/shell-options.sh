#!/bin/bash
# Program:
#	This is my first shell script,shows "Hello World!" in your screen.
# History:
# 2018/11/09 Jianghairui First release
PATH=$PATH
export PATH

echo "The script name is ==> $0"
echo "Total parameter number is ==> $#"
[ $# -lt 2 ] && echo "The number of parameter is less than 2. Stop here." && exit 0 
echo "Your whole parameter is ==> '$@'"
echo "The 1st parameter is ==> $1"
echo "The 2nd parameter is ==> $2"
