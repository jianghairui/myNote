#!/bin/bash
# Program:
#	This is my first shell script,shows "Hello World!" in your screen.
# History:
# 2018/11/09 Jianghairui First release
PATH=$PATH
export PATH
if [ "$1" == 'hello' ]; then
	echo "Hello,how are you ?"
elif [ "$1" == '' ]; then
	echo "Your MUST input parameters,ex> {$0 someword}"
else
	echo "The only parameter is 'hello',ex> {$0 hello}"
fi 
