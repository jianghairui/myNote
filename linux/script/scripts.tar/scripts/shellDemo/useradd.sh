#!/bin/bash
PATH=$PATH
export PATH
if [ ! -f accountlist ];then
	echo "accountlist not exist,please create a new list in this dir"
	exit 1
fi

usernames=$(cat accountlist)
for username in $usernames
do
	useradd -g myquotagrp -m -s /bin/bash $username
	echo $username:$username | chpasswd
#	chage -d 0 $username
done
